
All Yeti installation logs will be placed here.