This folder is used for storing data for OSGi XML contained in bundle com.prosyst.mbs.osgi.metatyp.bundle.
