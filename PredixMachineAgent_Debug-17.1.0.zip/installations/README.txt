
The Yeti process will monitor this folder for software to install. The software must be a zip with a install.bat/install.sh inside.

